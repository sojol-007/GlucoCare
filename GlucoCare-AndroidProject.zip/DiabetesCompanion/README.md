# GlucoCare — Diabetes Companion (Android)

A native Android app: editable daily reminders (insulin, glucose checks, meals,
water, exercise) with REAL system alarms — powered by Android's own AlarmManager,
so they fire even when the app is closed and the screen is off. Each alert repeats
every 24 hours automatically and shows Snooze (10 min) / Dismiss buttons right on
the notification. Times are shown in 12-hour AM/PM format.

I cannot compile this into a ready .apk myself (no Android build tools in my
environment) — but here are two free ways for you to get a real, installable
GlucoCare.apk from this exact project, no coding required.

---

## Option A — Build in the cloud with GitHub Actions (no software to install)

1. Create a free account at github.com if you don't have one.
2. Create a new repository (e.g. "GlucoCare"), then upload every file/folder from
   this project into it (drag-and-drop works on github.com, or use `git push`).
3. Go to the repo's **Actions** tab. A workflow called "Build APK" runs
   automatically on push (or click "Run workflow" to trigger it manually).
4. When it finishes (a couple of minutes), open the completed run and download
   the **GlucoCare-debug-apk** artifact — that's your installable APK, zipped.

## Option B — Build locally with Android Studio

1. Install Android Studio (free): https://developer.android.com/studio
2. File → Open → select this "DiabetesCompanion" folder.
3. Let Gradle sync finish (it downloads what it needs automatically — this part
   needs your own internet connection, not mine).
4. Build → Build App Bundle(s)/APK(s) → Build APK(s).
5. Find it at: app/build/outputs/apk/debug/app-debug.apk

---

## Installing the APK on your phone

1. Get the .apk file onto your phone (email it to yourself, upload to Google
   Drive, or plug in via USB and copy it over).
2. Tap the file on your phone. Android will prompt you to allow "install
   unknown apps" for whichever app you opened it with (Files, Gmail, Chrome,
   etc.) — allow it just for that app.
3. Tap Install, then Open.
4. On first launch, allow the notification permission when asked, and tap the
   yellow banner (if it appears) to allow "exact alarms" — this is what makes
   the reminders fire precisely on time.

That's it — GlucoCare is now a real app icon on the home screen, with reminders
that work like any other alarm app on the phone.

## Notes
- Every reminder's icon, label, time, and on/off state is fully editable —
  there are no hidden medical defaults; you set every time yourself.
- Reminders repeat daily; if the phone restarts, they're automatically
  re-armed on boot.
- This app only reminds and tracks — it never suggests doses, targets, or
  medical advice. Always follow your own doctor's plan.
