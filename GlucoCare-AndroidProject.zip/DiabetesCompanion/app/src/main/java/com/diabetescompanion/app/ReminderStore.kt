package com.diabetescompanion.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ReminderStore {
    private const val PREFS = "glucocare_prefs"
    private const val KEY_REMINDERS = "reminders"

    fun defaultReminders(): MutableList<Reminder> {
        val defs = listOf(
            Triple("🩸", "Glucose/CGM check", 7 to 0),
            Triple("💉", "Insulin", 7 to 15),
            Triple("🍳", "Breakfast", 7 to 30),
            Triple("💧", "Water", 9 to 0),
            Triple("🩸", "Glucose check", 11 to 0),
            Triple("💧", "Water", 11 to 30),
            Triple("🍽️", "Lunch", 13 to 0),
            Triple("💉", "Insulin (if prescribed)", 13 to 15),
            Triple("💧", "Water", 15 to 0),
            Triple("🚶", "Exercise / activity", 16 to 30),
            Triple("🩸", "Glucose check", 18 to 0),
            Triple("🍲", "Dinner", 19 to 0),
            Triple("💉", "Insulin", 19 to 15),
            Triple("💧", "Water", 20 to 0),
            Triple("🩸", "Bedtime glucose check", 21 to 30),
            Triple("😴", "Sleep", 22 to 0)
        )
        return defs.mapIndexed { i, t ->
            Reminder((i + 1).toLong(), t.first, t.second, t.third.first, t.third.second, true)
        }.toMutableList()
    }

    fun load(context: Context): MutableList<Reminder> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_REMINDERS, null) ?: return defaultReminders()
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<Reminder>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Reminder(
                        o.getLong("id"), o.getString("icon"), o.getString("label"),
                        o.getInt("hour"), o.getInt("minute"), o.getBoolean("enabled")
                    )
                )
            }
            if (list.isEmpty()) defaultReminders() else list
        } catch (e: Exception) {
            defaultReminders()
        }
    }

    fun save(context: Context, reminders: List<Reminder>) {
        val arr = JSONArray()
        reminders.forEach {
            val o = JSONObject()
            o.put("id", it.id); o.put("icon", it.icon); o.put("label", it.label)
            o.put("hour", it.hour); o.put("minute", it.minute); o.put("enabled", it.enabled)
            arr.put(o)
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_REMINDERS, arr.toString()).apply()
    }

    fun nextId(context: Context): Long {
        val list = load(context)
        return (list.maxOfOrNull { it.id } ?: 0L) + 1
    }
}
