package com.diabetescompanion.app

data class Reminder(
    val id: Long,
    var icon: String,
    var label: String,
    var hour: Int,
    var minute: Int,
    var enabled: Boolean
)
