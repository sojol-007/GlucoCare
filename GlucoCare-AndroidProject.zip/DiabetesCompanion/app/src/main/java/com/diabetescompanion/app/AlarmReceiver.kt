package com.diabetescompanion.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

// Handles: the alarm firing, the Snooze button, and the Dismiss button.
class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_FIRE = "com.diabetescompanion.app.ACTION_FIRE"
        const val ACTION_SNOOZE = "com.diabetescompanion.app.ACTION_SNOOZE"
        const val ACTION_DISMISS = "com.diabetescompanion.app.ACTION_DISMISS"
        const val CHANNEL_ID = "glucocare_reminders"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", 0L)
        val icon = intent.getStringExtra("icon") ?: "⏰"
        val label = intent.getStringExtra("label") ?: "Reminder"
        val hour = intent.getIntExtra("hour", 0)
        val minute = intent.getIntExtra("minute", 0)

        when (intent.action) {
            ACTION_DISMISS -> {
                NotificationManagerCompat.from(context).cancel(id.toInt())
            }
            ACTION_SNOOZE -> {
                NotificationManagerCompat.from(context).cancel(id.toInt())
                scheduleSnooze(context, id, icon, label, hour, minute)
            }
            else -> {
                showNotification(context, id, icon, label, hour, minute)
                // Reschedule this same reminder ~24 hours later (next day, same time) -> true daily repeat
                val reminders = ReminderStore.load(context)
                reminders.find { it.id == id }?.let { AlarmScheduler.scheduleOne(context, it) }
            }
        }
    }

    private fun scheduleSnooze(context: Context, id: Long, icon: String, label: String, hour: Int, minute: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val snoozeTime = System.currentTimeMillis() + 10 * 60 * 1000
        val snoozeIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_FIRE
            putExtra("id", id); putExtra("icon", icon); putExtra("label", label)
            putExtra("hour", hour); putExtra("minute", minute)
        }
        val pi = PendingIntent.getBroadcast(
            context, (id + 900000).toInt(), snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, snoozeTime, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, snoozeTime, pi)
        }
    }

    private fun showNotification(context: Context, id: Long, icon: String, label: String, hour: Int, minute: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "GlucoCare reminders", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Daily diabetes routine reminders"
                enableVibration(true)
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }

        val timeText = formatTime12h(hour, minute)

        val dismissIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_DISMISS
            putExtra("id", id)
        }
        val dismissPi = PendingIntent.getBroadcast(
            context, (id + 700000).toInt(), dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snoozeIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_SNOOZE
            putExtra("id", id); putExtra("icon", icon); putExtra("label", label)
            putExtra("hour", hour); putExtra("minute", minute)
        }
        val snoozePi = PendingIntent.getBroadcast(
            context, (id + 800000).toInt(), snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openIntent = Intent(context, MainActivity::class.java)
        val openPi = PendingIntent.getActivity(
            context, id.toInt(), openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("$icon $label")
            .setContentText("It's time — $timeText")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(openPi)
            .setAutoCancel(true)
            .addAction(0, "Snooze 10m", snoozePi)
            .addAction(0, "Dismiss", dismissPi)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(id.toInt(), notification)
        } catch (e: SecurityException) { }
    }
}
