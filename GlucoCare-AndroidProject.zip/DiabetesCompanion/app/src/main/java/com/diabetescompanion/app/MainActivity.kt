package com.diabetescompanion.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var reminders: MutableList<Reminder>
    private lateinit var adapter: ReminderAdapter
    private lateinit var permissionBanner: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        reminders = ReminderStore.load(this)
        AlarmScheduler.scheduleAll(this, reminders)

        val recycler = findViewById<RecyclerView>(R.id.recyclerView)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = ReminderAdapter(reminders, this)
        recycler.adapter = adapter

        findViewById<FloatingActionButton>(R.id.addBtn).setOnClickListener {
            val newReminder = Reminder(ReminderStore.nextId(this), "⏰", "New reminder", 12, 0, true)
            reminders.add(newReminder)
            ReminderStore.save(this, reminders)
            AlarmScheduler.scheduleOne(this, newReminder)
            adapter.notifyItemInserted(reminders.size - 1)
        }

        findViewById<Button>(R.id.lowSugarBtn).setOnClickListener {
            showReference(
                "🍬 Low blood sugar (hypo)",
                "Signs: shaking, sweating, hunger, weakness, dizziness, confusion.\n\n" +
                "If glucose is low, follow your own hypo plan — commonly 15g fast-acting carbs, then recheck in 15 minutes.\n\n" +
                "If severe or unconscious: never give food or drink by mouth. Use glucagon if prescribed, and get emergency help right away."
            )
        }

        findViewById<Button>(R.id.highSugarBtn).setOnClickListener {
            showReference(
                "🚨 High sugar / possible DKA",
                "Warning signs: vomiting, stomach pain, fast/deep breathing, fruity-smelling breath, severe weakness, confusion, or high ketones.\n\n" +
                "Treat as urgent — follow your sick-day/ketone plan and get medical help promptly. Water helps but is not a substitute for insulin."
            )
        }

        permissionBanner = findViewById(R.id.permissionBanner)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        checkExactAlarmPermission()
    }

    private fun checkExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !AlarmScheduler.canScheduleExact(this)) {
            permissionBanner.visibility = TextView.VISIBLE
            permissionBanner.text = "⚠️ Tap here to allow exact alarms so reminders stay on time"
            permissionBanner.setOnClickListener {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        } else {
            permissionBanner.visibility = TextView.GONE
        }
    }

    private fun showReference(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Close", null)
            .show()
    }
}
