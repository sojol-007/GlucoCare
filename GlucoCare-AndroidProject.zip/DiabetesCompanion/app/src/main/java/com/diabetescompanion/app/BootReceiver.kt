package com.diabetescompanion.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Re-registers every alarm after the phone reboots (Android clears alarms on restart).
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val reminders = ReminderStore.load(context)
            AlarmScheduler.scheduleAll(context, reminders)
        }
    }
}
