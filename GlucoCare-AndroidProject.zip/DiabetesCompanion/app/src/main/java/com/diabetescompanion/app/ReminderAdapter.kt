package com.diabetescompanion.app

import android.app.TimePickerDialog
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.recyclerview.widget.RecyclerView

class ReminderAdapter(
    private val items: MutableList<Reminder>,
    private val context: android.content.Context
) : RecyclerView.Adapter<ReminderAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: EditText = view.findViewById(R.id.iconInput)
        val label: EditText = view.findViewById(R.id.labelInput)
        val time: TextView = view.findViewById(R.id.timeBtn)
        val enabled: SwitchCompat = view.findViewById(R.id.enabledSwitch)
        val delete: ImageButton = view.findViewById(R.id.deleteBtn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_reminder, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val r = items[position]
        holder.icon.setText(r.icon)
        holder.label.setText(r.label)
        holder.time.text = formatTime12h(r.hour, r.minute)
        holder.enabled.isChecked = r.enabled

        holder.icon.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) { r.icon = holder.icon.text.toString(); persist(r) }
        }
        holder.label.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) { r.label = holder.label.text.toString(); persist(r) }
        }
        holder.time.setOnClickListener {
            TimePickerDialog(context, { _, h, m ->
                r.hour = h; r.minute = m
                holder.time.text = formatTime12h(h, m)
                persist(r)
            }, r.hour, r.minute, false).show() // false = 12-hour clock with AM/PM
        }
        holder.enabled.setOnCheckedChangeListener { _, checked ->
            r.enabled = checked
            persist(r)
        }
        holder.delete.setOnClickListener {
            AlarmScheduler.cancelOne(context, r)
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                items.removeAt(pos)
                notifyItemRemoved(pos)
            }
            ReminderStore.save(context, items)
        }
    }

    private fun persist(r: Reminder) {
        ReminderStore.save(context, items)
        AlarmScheduler.scheduleOne(context, r)
    }
}
