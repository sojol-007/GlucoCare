package com.diabetescompanion.app

fun formatTime12h(hour: Int, minute: Int): String {
    val period = if (hour < 12) "AM" else "PM"
    var h12 = hour % 12
    if (h12 == 0) h12 = 12
    return "%d:%02d %s".format(h12, minute, period)
}
